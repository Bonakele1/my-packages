# mypackage 
This library was created as an exaple of how to create a python package

